# Robo Msg and Srv

[文档](https://t1a6a5tmdk.feishu.cn/docx/Zhwgd9W9QokGvaxIWHHcmtqmnQh)

## Task msgs
任务管理模块消息

## Agv msgs
AGV 本体驱动消息

## perception_msgs
感知模块

## Driver msgs
老版本驱动层消息,暂时弃用，由agv_msgs代替

## Device msgs
临时版本